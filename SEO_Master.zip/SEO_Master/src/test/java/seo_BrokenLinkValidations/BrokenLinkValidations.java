package seo_BrokenLinkValidations;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;

public class BrokenLinkValidations {

	WebDriver driver;
	HttpURLConnection huc = null;
	String path = "D:\\";
	String filename = "TestData.xls";
	String ValidURL = "ValidURL";
	String BrokenURL = "BrokenURL";
	String sheetotherDomain = "OtherDomainURL";
	String sheetNullURL = "NullURL";
	String url = "";
	int count = 0;
	String homePage = "https://stfc.in";

	int respCode = 200;

	@BeforeMethod

	public void beforeMethod() throws Exception {

		WebDriverManager.chromedriver().setup();

		driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		driver.get("https://www.stfc.in/");
	}

	@Test
	public void EmptyURL_verificatin() throws Exception {

		String homePage = "https://www.stfc.in/";
		String url = "";
		HttpURLConnection huc = null;
		int respCode = 200;

		WebDriverManager.chromedriver().setup();

		WebDriver driver;

		driver = new ChromeDriver();

		driver.manage().window().maximize();

		driver.get(homePage);

		System.out.println(driver.getTitle());

		List<WebElement> links = driver.findElements(By.tagName("a"));

		Thread.sleep(2000);

		Iterator<WebElement> it = links.iterator();

		while (it.hasNext()) {

			System.out.println(count);

			url = it.next().getAttribute("href");

//        System.out.println(url);

			if (url == null || url.isEmpty()) {

				// objwriteExcel.write_to_Excel(path, filename, sheetNullURL, url);

				System.out.println("URL is either not configured for anchor tag or it is empty");
				continue;
			}

			if (!url.startsWith(homePage)) {
				// objwriteExcel.write_to_Excel(path, filename, sheetotherDomain, url);
				System.out.println(url + "" + "other domain");
				System.out.println("URL belongs to another domain, skipping it.");
				continue;
			}

			try {
				huc = (HttpURLConnection) (new URL(url).openConnection());

				huc.setRequestMethod("HEAD");

				huc.connect();

				respCode = huc.getResponseCode();

				if (respCode >= 400) {
					// objwriteExcel.write_to_Excel(path, filename, BrokenURL, url);
					System.out.println(url + " is a broken link" + " " + respCode);
				} else {
					// objwriteExcel.write_to_Excel(path, filename, ValidURL, url);
					System.out.println(url + " is a valid link" + " " + respCode);

				}

			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			count++;
		}

		driver.quit();

	}

}
