package KeywordTest;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

public class Keyword_Validation {
  @Test
  public void testcase1() {
	  
	  System.out.println("tested");
	  
	  
  }
  @BeforeMethod
  public void beforeMethod() {
  }

}
