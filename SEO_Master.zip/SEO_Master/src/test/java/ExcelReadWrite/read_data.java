package ExcelReadWrite;

import java.util.ArrayList;
import java.util.Iterator;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class read_data {
	@Test()
	@DataProvider(name = "getTestData" )
	public void getdatafromexcel(String LunchURL) {
		System.out.println(LunchURL);

	}

	@DataProvider
	public Iterator<Object[]> getTestData() {
		ArrayList<Object[]> testData = Excel_Utils.getDataFromexcel();
		return testData.iterator();
	}
}