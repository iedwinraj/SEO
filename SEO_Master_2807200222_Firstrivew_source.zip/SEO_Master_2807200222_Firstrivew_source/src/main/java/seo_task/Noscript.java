package seo_task;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Noscript {

	public static void main(String[] args) {

		RestAssured.baseURI = "https://reqres.in/api/users?page=1";
		RequestSpecification httpRequest1 = RestAssured.given();
		Response responseA1 = httpRequest1.get("");
		String body1 = responseA1.getBody().asString();
		
		System.out.println("BODY:" + body1);
		System.out.println(responseA1.jsonPath());
	}
}
