package seo_task;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import ExcelUtil.Excel_Reader;
import ExcelUtil.writeExcel;

import io.github.bonigarcia.wdm.WebDriverManager;

public class h1tag_validations extends writeExcel {
	WebDriver driver;
	ArrayList<String> listofurl = new ArrayList<String>();

	String path = System.getProperty("user.dir");
	String filename = "\\Data\\h1tag_Result.xls";
	String sheetValidURL = "ValidURL";
	String BrokenURL = "BrokenURL";
	String sheetotherDomain = "OtherDomainURL";
	String sheetNullURL = "NullURL";
	String sheetHttpHead = "HttpHeader";
	String sheetAllLinks = "AllLinks";
	String Sheeth1tag = "h1Tag";
	String columName = "PageURL";
	String SheetURL = "Input";
	writeExcel objwriteExcel = new writeExcel();

	public void verifyLink() throws Exception {

		Excel_Reader readexcel = new Excel_Reader(path + filename);

		String homeURL = readexcel.getCellData(SheetURL, columName, 2);

		String homePage = homeURL;
		String url = "";
		// String url1 = "http://";
		HttpURLConnection huc = null;
		int respCode = 200;

		WebDriverManager.chromedriver().setup();

		driver = new ChromeDriver();

		driver.manage().window().maximize();

		driver.get(homePage);

		System.out.println(driver.getTitle());

		List<WebElement> links = driver.findElements(By.tagName("a"));

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e2) {
			e2.printStackTrace();
		}

		Iterator<WebElement> it = links.iterator();

		// driver.quit();

		while (it.hasNext()) {

			url = it.next().getAttribute("href");

			
			if (url.startsWith("http")) {
				listofurl.add(url);
				objwriteExcel.write_to_Excel(path, filename, sheetAllLinks, url);
			}
			
		}

		Thread.sleep(3000);

		driver.quit();

	}

	public void h1tagcount() throws InterruptedException {

		for (String urlstring : listofurl) {

			if (urlstring.length() > 0 && !(urlstring == null)) {
				WebDriverManager.chromedriver().setup();
				driver = new ChromeDriver();
				System.out.println(urlstring);
				
				try {
					driver.get(urlstring);
				} catch (Exception e1) {
					driver.get(urlstring);
					e1.printStackTrace();
				}

				Thread.sleep(2000);

				List<WebElement> findElementsh1 = driver.findElements(By.xpath("//h1"));

				System.out.println(findElementsh1.size());
				int Totalh1Tag = findElementsh1.size();
				try {
					if (Totalh1Tag > 1 && urlstring.length() > 0) {
						System.out.println("More than one h1 tag :" + Totalh1Tag);
						System.out.println("Test" + urlstring);
						objwriteExcel.write_to_Excel(path, filename, Sheeth1tag, urlstring + "     " + Totalh1Tag);

					}
				} catch (IOException e) {
					e.printStackTrace();
					System.out.println(e.getMessage());
				}
				Thread.sleep(5000);
				driver.quit();
			}

		}

	}

}
