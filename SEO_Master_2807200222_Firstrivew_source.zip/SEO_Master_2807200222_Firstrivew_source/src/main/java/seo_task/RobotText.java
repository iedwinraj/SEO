package seo_task;



import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import ExcelUtil.Excel_Reader;
import ExcelUtil.writeExcel;
import io.github.bonigarcia.wdm.WebDriverManager;
import jxl.common.Assert;

public class RobotText extends writeExcel {

	public void robotstextfileExist() throws InterruptedException, MalformedURLException, IOException {

		writeExcel objwriteExcel = new writeExcel();
		String path = System.getProperty("user.dir");
		System.out.println(path);
		String filename = "\\Data\\Robots_Result.xls";

		String columName = "PageURL";
		String SheetURL = "Input";
		String SheetRobotsContent = "RobotsContent";

		if (path.isBlank()) {
			System.out.println("Please Enter Valid path");
		}

		Excel_Reader readexcel = new Excel_Reader(path + filename);

		String GivenURL = readexcel.getCellData(SheetURL, columName, 2);

		HttpURLConnection huc = null;

		int respCode = 200;

		WebDriver driver;

		WebDriverManager.chromedriver().setup();

		driver = new ChromeDriver();

		// driver.manage().window().maximize();

		driver.get(GivenURL);

		huc = (HttpURLConnection) (new URL(GivenURL).openConnection());

		huc.setRequestMethod("HEAD");

		huc.connect();

		respCode = huc.getResponseCode();

		if (respCode >= 400) {
			// objwriteExcel.write_to_Excel(path, filename, BrokenURL, url);
			System.out.println(GivenURL + " is a broken link" + " " + respCode);
		} else {
			// objwriteExcel.write_to_Excel(path, filename, sheetValidURL, url);
			System.out.println(GivenURL + " is a valid link" + " " + respCode);

		}

		Thread.sleep(2000);

		try {
			List<WebElement> sitemapurls = driver.findElements(By.xpath("//*[contains(text(),'https:')]"));
			System.out.println(sitemapurls.size());
			for (WebElement webElement : sitemapurls) {
				System.out.println(webElement.getText());

				if (!webElement.getText().isBlank()) {
					objwriteExcel.write_to_Excel(path, filename, SheetRobotsContent, webElement.getText());
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		driver.quit();
	}

}
