package baseClass;

import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

public class BaseTest {

	String dataSheetName ="TestDataKeyword";

	
	WebDriver driver;
	DriverFactory df;
	public Properties prop;

	@BeforeTest
	public void setUp(String browserName, String browserVersion) {
		df = new DriverFactory();
		prop = df.init_prop();
		String browser = prop.getProperty("browser");

		if (browserName != null) {
			browser = browserName;
		}

		driver = df.init_driver(browser, browserVersion);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(120, TimeUnit.SECONDS);
		driver.manage().timeouts().setScriptTimeout(120, TimeUnit.SECONDS);
		driver.get(prop.getProperty("url"));
		driver.getCurrentUrl().equalsIgnoreCase("https://www.selenium.dev/");
	}

	@AfterTest
	public void tearDown() {
//		driver.quit();
	}

	@DataProvider(name = "getdata")

	public Object[][] getData() {
		return ReadExcelwithArray.readData(dataSheetName);

	}

}
