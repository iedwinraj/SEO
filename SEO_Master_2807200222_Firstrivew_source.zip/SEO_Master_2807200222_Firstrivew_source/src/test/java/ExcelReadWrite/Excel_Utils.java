package ExcelReadWrite;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel_Utils {
    
static Excel_Reader reader;
    
    public static  ArrayList<Object[]> getDataFromexcel() {
        ArrayList<Object[]> myData=new ArrayList<Object[]>();
        try {
        
            reader=new Excel_Reader("D:\\SEO_Regression_Test_Suite.xlsx");
            
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
		return myData;
    }

    public static void writeinexcel1(String value) throws Exception {
		Thread.sleep(2000);
		File fis = new File("D:\\eclipse-workspace\\SEO_Master\\Data\\h1tag_Result.xls");
		FileInputStream excelloc = new FileInputStream(fis);
		XSSFWorkbook wb = new XSSFWorkbook(excelloc);
		XSSFSheet s = wb.getSheetAt(0);
		XSSFRow row = s.getRow(0);
		XSSFCell c = row.createCell(3);
		c.setCellValue(value);
		FileOutputStream out = new FileOutputStream(fis);
		wb.write(out);
		out.close();
	}


}
