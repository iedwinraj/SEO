package seo_task_test;

import java.io.IOException;
import java.net.MalformedURLException;

import org.testng.annotations.Test;
import seo_task.*;

public class RobotFileTest extends RobotText {

	@Test()
	public void robottest() throws IOException {
	
		try {
			robotstextfileExist();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	
}
