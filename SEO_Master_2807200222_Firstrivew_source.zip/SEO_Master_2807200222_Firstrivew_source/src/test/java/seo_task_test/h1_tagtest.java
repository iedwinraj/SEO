package seo_task_test;

import org.testng.annotations.Test;
import seo_task.h1tag_validations;

public class h1_tagtest extends h1tag_validations {
	
	
	@Test()
	public void LinkVerifyTest() throws Exception {

		verifyLink();
	}
	
	
	@Test()
	public void h1tagCountTest() throws Exception {

		h1tagcount();
	}
	
}
