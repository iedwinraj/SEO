package seo_task_test;

import org.testng.annotations.Test;
import seo_task.*;

public class Sitemap_Reader extends SitemapURLs {

		@Test
		public void sitemapfileExistTest() throws Exception{
			sitemapfileExist();
						
		} 
		@Test(dependsOnMethods = {"sitemapfileExistTest"} )
		public void sitemapurl_listTest() throws Exception{
			
			sitemapurl_list();
		}
	

}