package seo_task_test;

import org.testng.annotations.Test;

import seo_task.Broken_images_validation;

public class Broken_images_validationTest extends Broken_images_validation {
	@Test
	public void brokenImageTest() {
		verifyImages();

	}

}
